package alfredo.relog.Tabs;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import alfredo.relog.R;


/**
 * Created by TheNewRol on 17/04/2017.
 */

public class Alarma extends Fragment{

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View alarma = inflater.inflate(R.layout.alarma, container, false);
        //setText("hola");
        return alarma;
    }

    public void setText(String texto){
        //TextView textView = (TextView) getView().findViewById(R.id.fecha);
        //textView.setText(texto);
    }

}
